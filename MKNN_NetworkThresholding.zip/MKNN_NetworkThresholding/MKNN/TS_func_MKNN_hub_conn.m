function hubs_x = TS_nw_hub(mutual_X)
x = mutual_X;
hd_x = degrees_und(x);
BC_x = betweenness_bin(x);
mean_degree_x = mean(hd_x);
sd_deg_x = std(hd_x); 
hbca = BC_x; % BC is betweenness centrality
mean_BC_x = mean(hbca);
sd_BC_x = std(hbca);
hubs_x = find((hd_x >=(mean_degree_x+sd_deg_x)) & (hbca >=(mean_BC_x+sd_BC_x)));
end