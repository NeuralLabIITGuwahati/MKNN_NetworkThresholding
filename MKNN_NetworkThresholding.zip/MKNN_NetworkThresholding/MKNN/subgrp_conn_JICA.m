
clc
close all
clear all
pwd
%tic
% NIMHANS data 180 PD 
%% 1. Load File

% HC: 70;
% PD: 180 num
cd 'C:\Users\TestPC\Desktop\MKNN'
% cd 'C:\Users\TestPC\Desktop\ALL\JICA\Connectivity'
load('Subgrp_subj_JICA.mat');
[num, txt, raw]  = xlsread('HC_PD_NIMHANS.xlsx'); % excel sheet with all subjects Age, Gender, Diagnosis data

txt = txt(2:end,:);
Diag= num(:,3); % HC: 2 & PD: 1
% HCnames = txt(find(Diag == 2),1); % Names of HC 
% HC_sl  =  find(Diag==2); % Sl num of HC in the excel as well as SBM matrix
PDnames = txt(find(Diag == 1),1); % Names of PD
PD_sl  =  find(Diag==1); % Sl num of PD in the excel as well as SBM matrix
% Males = find(num(:,1) ==1); % Sl no of males in the entire dataset
% Females = find(num(:,1) ==0); % Sl no of females in the entire dataset
PD_Age = num(PD_sl,2); % 2nd column has age values
PD_Gender = num(PD_sl,1);% Male: 1 & Female : 0
% HC_Age = num(HC_sl,2); 
% HC_Gender = num(HC_sl,1);
A_age = PD_Age(Grp_A_idx,:);
B_age = PD_Age(Grp_B_idx,:);
AB_age = PD_Age(Grp_AB_idx,:);
A_gender = PD_Gender(Grp_A_idx,:);
B_gender = PD_Gender(Grp_B_idx,:);
AB_gender = PD_Gender(Grp_AB_idx,:);

%% 2. Regional GM vol of 56 ROIs as per LPBA40 atlas
rGM =  readtable('PD_rGMV_NIMHANS.csv'); % 179 sub * 56 ROIs
rWM =  readtable('PD_rWMV_NIMHANS.csv'); % 179 sub * 56 ROIs
rGMV = table2array(rGM(1:end,2:end));
rWMV = table2array(rWM(1:end,2:end));
PD_GM = rGMV;
PD_WM = rWMV;

sub_id = table2array(rGM(:,1));
A_GM = PD_GM(Grp_A_idx,:);
B_GM = PD_GM(Grp_B_idx,:);
AB_GM = PD_GM(Grp_AB_idx,:);

A_WM = PD_WM(Grp_A_idx,:);
B_WM = PD_WM(Grp_B_idx,:);
AB_WM = PD_WM(Grp_AB_idx,:);

A_X = [ones(size(A_age)) A_age A_gender A_age.*A_gender];
B_X = [ones(size(B_age)) B_age B_gender B_age.*B_gender];
AB_X = [ones(size(AB_age)) AB_age AB_gender AB_age.*AB_gender];

%% 3. Multiple linear Regression : Regressing out the effect of age, gender and their combined effect

cA_GM = TS_func_regression_conn(A_GM,A_X,A_age,A_gender);
cB_GM = TS_func_regression_conn(B_GM,B_X,B_age,B_gender);
cAB_GM = TS_func_regression_conn(AB_GM,AB_X,AB_age,AB_gender);

cA_WM = TS_func_regression_conn(A_WM,A_X,A_age,A_gender);
cB_WM = TS_func_regression_conn(B_WM,B_X,B_age,B_gender);
cAB_WM = TS_func_regression_conn(AB_WM,AB_X,AB_age,AB_gender);


%% 4. Interregional Correlation Matrix- Pearson's Correlation (56*56 matrix) #sub < #regions
for i = 1:56
    for j = 1:56
        corr_A(i,j) = corr(cA_GM(:,i),cA_WM(:,j)); 
        corr_B(i,j) = corr(cB_GM(:,i),cB_WM(:,j));
        corr_AB(i,j) = corr(cAB_GM(:,i),cAB_WM(:,j));
    end
end
save ('A_wt_corr_mat.txt', 'corr_A', '-ascii')

save ('B_wt_corr_mat.txt', 'corr_B', '-ascii')

save ('AB_wt_corr_mat.txt', 'corr_AB', '-ascii')

%% Mutual
k = 7;
[Assoc_A, Mutual_A, num_edges_A, Density_A] = TS_func_MKNN_mutual(corr_A,k);
saveas(gcf, 'MKNN_graph_A.tif') % saved in above mentioned path

[Assoc_B, Mutual_B, num_edges_B, Density_B] = TS_func_MKNN_mutual(corr_B,k);
saveas(gcf, 'MKNN_graph_B.tif') % saved in above mentioned path

[Assoc_AB, Mutual_AB, num_edges_AB, Density_AB] = TS_func_MKNN_mutual(corr_AB,k);
saveas(gcf, 'MKNN_graph_AB.tif') % saved in above mentioned path


%% 6. Network Connectivity
% Binarization for A based on sparsity Threshold based on Sanabria-Diaz et al., 2010 Surface area and cortical thickness descriptors reveal different attributes of the structural human brain networks
% Network Metric Calculation
% Sigma calculation for A with 1000 random networks per sparsity
[deg_A, Avg_deg_A, density_A, transit_A, eff_local_A, eff_global_A, modul_A, assortativity_A, BC_A, participation_coef_A, eigen_vector_centrality_A, pl_A, lambda_A, gamma_A, sigma_A, clust_coef_A] = TS_func_MKNN_nw_conn_metrics(Mutual_A);
[deg_B, Avg_deg_B, density_B, transit_B, eff_local_B, eff_global_B, modul_B, assortativity_B, BC_B, participation_coef_B, eigen_vector_centrality_B, pl_B, lambda_B, gamma_B, sigma_B, clust_coef_B] = TS_func_MKNN_nw_conn_metrics(Mutual_B);
[deg_AB, Avg_deg_AB, density_AB, transit_AB, eff_local_AB, eff_global_AB, modul_AB, assortativity_AB, BC_AB, participation_coef_AB, eigen_vector_centrality_AB, pl_AB, lambda_AB, gamma_AB, sigma_AB, clust_coef_AB] = TS_func_MKNN_nw_conn_metrics(Mutual_AB);

%% 8. Bar Plot after running all metric measurements for each subgroup (A, B and AB)

% Plot of threshold vs average degree
yavgDeg = [Avg_deg_A, Avg_deg_B, Avg_deg_AB];

% Plot of threshold vs Density
ydens = [density_A, density_B, density_AB];

% Plot of threshold vs global efficiency
yge = [eff_global_A, eff_global_B, eff_global_AB];

% Plot of threshold vs path length
ypl = [pl_A(1,1),pl_B(1,1),pl_AB(1,1)];

% Plot of threshold vs assortativity
yassort = [assortativity_A, assortativity_B, assortativity_AB];

% Plot of  threshold vs transitivity
ytransit = [transit_A, transit_B, transit_AB];

% Plot of  threshold vs lambda 
ylambda = [lambda_A, lambda_B, lambda_AB];

X = categorical({'Average Degree','Density','Global Efficiency','Path Length', 'Assortativity', 'Transitivity', 'Lambda'});
X = reordercats(X,{'Average Degree','Density','Global Efficiency','Path Length', 'Assortativity', 'Transitivity', 'Lambda'});
y_metrics = [yavgDeg; ydens; yge; ypl; yassort; ytransit; ylambda];
figure
b = bar(X,y_metrics,'FaceColor','flat');
for k = 1:size(y_metrics,2)
    b(k).CData = k;
end
legend('Subgroup A','Subgroup B','Subgroup AB');

%%  9. Hubs at sparsity of 0.55 since network was constructed at 0.55  is a value with good density(0.45) and sparsity(0.55), also used in BrainNet

hubs_A = TS_func_MKNN_hub_conn(Mutual_A);
hubs_B = TS_func_MKNN_hub_conn(Mutual_B);
hubs_AB = TS_func_MKNN_hub_conn(Mutual_AB);

common_A_B = intersect(hubs_A,hubs_B);
common_A_AB = intersect(hubs_A,hubs_AB);
common_B_AB = intersect(hubs_B,hubs_AB);
Common_A_B_AB = intersect(common_A_B,hubs_AB);

%% 5. Association matrix - Weighted undirected matrix
% cd 'C:\Users\TestPC\Desktop\Conn_PPMI\Plots'
mat = 'A';
TS_func_association_mat_conn(Mutual_A,mat)
saveas(gcf, 'MKNN_graph_A.png') % saved in above mentioned path

mat = 'B';
TS_func_association_mat_conn(Mutual_B,mat)
saveas(gcf, 'MKNN_graph_B.png') % saved in above mentioned path

mat = 'AB';
TS_func_association_mat_conn(Mutual_AB,mat)
saveas(gcf, 'MKNN_graph.png') % saved in above mentioned path

%% Group comparision of metrics
[h p ci stat] = ttest2(clust_coef_A,clust_coef_B)
[h p ci stat] = ttest2(clust_coef_A,clust_coef_AB)
[h p ci stat] = ttest2(clust_coef_B,clust_coef_AB)
[h p ci stat] = ttest2(eff_local_A,eff_local_B)
[h p ci stat] = ttest2(eff_local_A,eff_local_AB)
[h p ci stat] = ttest2(eff_local_B,eff_local_AB)
[h p ci stat] = ttest2(participation_coef_A,participation_coef_B)
[h p ci stat] = ttest2(participation_coef_A,participation_coef_AB)
[h p ci stat] = ttest2(participation_coef_B,participation_coef_AB)
[h p ci stat] = ttest2(gamma_A,gamma_B)
[h p ci stat] = ttest2(gamma_A,gamma_AB)
[h p ci stat] = ttest2(gamma_B,gamma_AB)
[h p ci stat] = ttest2(eigen_vector_centrality_A,eigen_vector_centrality_B)
[h p ci stat] = ttest2(eigen_vector_centrality_A,eigen_vector_centrality_AB)
[h p ci stat] = ttest2(eigen_vector_centrality_B,eigen_vector_centrality_AB)
[h p ci stat] = ttest2(BC_A,BC_B)
[h p ci stat] = ttest2(BC_A,BC_AB)
[h p ci stat] = ttest2(BC_B,BC_AB)


















% %% 7. Plot after running all metric measurements for each subgroup (A, B and AB)
% 
% % Plot of threshold vs mean clust_coeff
% nw_metric = 'Mean Clustering coefficient';
% TS_func_plot_nw_metrics(mean(clust_coef_A,1), mean(clust_coef_B,1), mean(clust_coef_AB,1), nw_metric)
% saveas(gcf, 'A_B_AB_clust_coef.png') % saved in above mentioned path
% 
% % Plot of threshold vs global efficiency
% nw_metric = 'Global efficiency';
% TS_func_plot_nw_metrics(eff_global_A, eff_global_B, eff_global_AB, nw_metric)
% saveas(gcf, 'A_B_AB_global eff.png') % saved in above mentioned path
% 
% % Plot of threshold vs mean path length
% nw_metric = 'Mean Path Length';
% TS_func_plot_nw_metrics(pl_A(:,1), pl_B(:,1), pl_AB(:,1), nw_metric)
% saveas(gcf, 'A_B_AB_pathlength.png') % saved in above mentioned path
% 
% % Plot of threshold vs mean local efficiency
% nw_metric = 'Mean Local Efficiency';
% TS_func_plot_nw_metrics(mean(eff_local_A,1), mean(eff_local_B,1),mean(eff_local_AB,1), nw_metric)
% saveas(gcf, 'A_B_AB_localeff.png') % saved in above mentioned path
% 
% % Plot of  threshold vs sigma (small world property)
% nw_metric = 'Mean Sigma';
% TS_func_plot_nw_metrics(mean_sigma_A, mean_sigma_B, mean_sigma_AB, nw_metric)
% saveas(gcf, 'A_B_AB_sigma.png') % saved in above mentioned path
% 
% % Plot of  threshold vs gamma 
% nw_metric = 'Mean Gamma';
% TS_func_plot_nw_metrics(mean_gamma_A, mean_gamma_B, mean_gamma_AB, nw_metric)
% saveas(gcf, 'A_B_AB_gamma.png') % saved in above mentioned path
% 
% % Plot of  threshold vs lambda 
% nw_metric = 'Mean Lambda';
% TS_func_plot_nw_metrics(mean_lambda_A, mean_lambda_B, mean_lambda_AB, nw_metric)
% saveas(gcf, 'A_B_AB_lambda.png')
% 
% % Plot of  threshold vs Betweenness Centrality 
% nw_metric = 'Mean Betweenness Centrality';
% TS_func_plot_nw_metrics(mean(BC_A,1), mean(BC_B,1), mean(BC_AB,1), nw_metric)
% saveas(gcf, 'A_B_AB_Betweenness_Centrality.png')
% 
% % Plot of  threshold vs Participation Coefficient 
% nw_metric = 'Mean Participation Coefficient';
% TS_func_plot_nw_metrics(mean(part_coef_A,1),mean(part_coef_B,1),mean(part_coef_AB,1), nw_metric)
% saveas(gcf, 'A_B_AB_participation Coefficient.png')
% 
% %%  8. Hubs at sparsity of 0.55 since network was constructed at 0.55  is a value with good density(0.45) and sparsity(0.55), also used in BrainNet
% 
% hubs_A = TS_func_hub_conn(deg_A,BC_A);
% hubs_B = TS_func_hub_conn(deg_B,BC_B);
% hubs_AB = TS_func_hub_conn(deg_AB,BC_AB);
% 
% %% 9. Binary undirected matrix figure at 1st level of sparsity (i.e.  0.55)
% 
% mat = 'A';
% TS_func_adjacency_mat_conn(A_3D,mat)
% saveas(gcf, 'BU_A_0pt55.tif')
% 
% mat = 'B';
% TS_func_adjacency_mat_conn(B_3D,mat)
% saveas(gcf, 'BU_B_0pt55.tif')
% 
% mat = 'AB';
% TS_func_adjacency_mat_conn(AB_3D,mat)
% saveas(gcf, 'BU_AB_0pt55.tif')
% 
% %% 10. Permutation Test for group differences in subgroups for clustering coefficient 
% nw_metric = 'Mean Clustering Coefficient';
% 
% mat1 = 'A'; 
% mat2 = 'B';
% TS_func_PermTest_CC(mean_clust_coef_A, mean_clust_coef_B, clust_coef_A, clust_coef_B, Sparsity, nw_metric, mat1, mat2)
% % legend({'Mean','Upperbound(95% CI)','Lowerbound(95% CI)','A vs  B'},'Location','north','Orientation','horizontal')
% saveas(gcf, 'Grp_diff_AvsB_CC.png') % saved in above mentioned path
% 
% mat1 = 'A'; 
% mat2 = 'AB';
% TS_func_PermTest_CC(mean_clust_coef_A, mean_clust_coef_AB, clust_coef_A, clust_coef_AB, Sparsity, nw_metric, mat1, mat2)
% % TS_func_PermTest_CC(mean_clust_coeff_A, mean_clust_coeff_B, clust_coef_A, clust_coef_B, Sparsity,nw_metric, mat1, mat2)
% saveas(gcf, 'Grp_diff_AvsAB_CC.png') % saved in above mentioned path
% 
% mat1 = 'B'; 
% mat2 = 'AB';
% TS_func_PermTest_CC(mean_clust_coef_B, mean_clust_coef_AB, clust_coef_B, clust_coef_AB, Sparsity, nw_metric, mat1, mat2)
% % TS_func_PermTest_CC(mean_clust_coeff_A, mean_clust_coeff_B, clust_coef_A, clust_coef_B, Sparsity,nw_metric, mat1, mat2)
% saveas(gcf, 'Grp_diff_BvsAB_CC.png') % saved in above mentioned path
% 
% %% Permutation Test for group differences in subgroups for local efficiency
% nw_metric = 'Mean Local Efficency';
% 
% mat1 = 'A'; mat2 = 'B';
% obs_diff = mean(eff_local_A,1) - mean(eff_local_B,1);% dim: 1*11   
% TS_func_permutation_test(eff_local_A, eff_local_B,obs_diff,Sparsity, nw_metric, mat1, mat2)
% legend({'Mean','Upperbound(95% CI)','Lowerbound(95% CI)','A vs B'},'Location','north','Orientation','horizontal')
% saveas(gcf, 'Grp_diff_AvsB_loceff.png') % saved in above mentioned path
% 
% mat1 = 'A'; mat2 = 'AB';
% obs_diff = mean(eff_local_A,1) - mean(eff_local_AB,1);% dim: 1*11   
% TS_func_permutation_test(eff_local_A, eff_local_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
% saveas(gcf, 'Grp_diff_AvsAB_loceff.png') % saved in above mentioned path
% 
% mat1 = 'B'; mat2 = 'AB';
% obs_diff = mean(eff_local_B,1) - mean(eff_local_AB,1);% dim: 1*11   
% TS_func_permutation_test(eff_local_B, eff_local_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
% saveas(gcf, 'Grp_diff_BvsAB_loceff.png') % saved in above mentioned path
% 
% %% Permutation Test for group differences in subgroups for Betweenness centrality 
% nw_metric = 'Betweenness Centrality';
% 
% mat1 = 'A'; mat2 = 'B';
% obs_diff = mean(BC_A,1)- mean(BC_B,1);% dim: 1*11    
% TS_func_permutation_test(BC_A, BC_B,obs_diff,Sparsity, nw_metric, mat1, mat2)
% ylim([-55 50])
% % legend({'Mean','Upperbound(95% CI)','Lowerbound(95% CI)','B vs A'},'Location','north','Orientation','horizontal')
% saveas(gcf, 'Grp_diff_AvsB_BC.png') % saved in above mentioned path
% 
% mat1 = 'A'; mat2 = 'AB';
% obs_diff = mean(BC_A,1)- mean(BC_AB,1);% dim: 1*11    
% TS_func_permutation_test(BC_A, BC_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
% ylim([-55 50])
% saveas(gcf, 'Grp_diff_AvsAB_BC.png') % saved in above mentioned path
% 
% mat1 = 'B'; mat2 = 'AB';
% obs_diff = mean(BC_B,1)- mean(BC_AB,1);% dim: 1*11    
% TS_func_permutation_test(BC_B, BC_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
% ylim([-55 50])
% saveas(gcf, 'Grp_diff_BvsAB_BC.png') % saved in above mentioned path
% 
% %% Permutation Test for group differences in subgroups for Participation coefficient
% nw_metric = 'Participation Coefficient';
% 
% mat1 = 'A'; mat2 = 'B';
% obs_diff = mean(part_coef_A,1)- mean(part_coef_B,1);% dim: 1*11   
% TS_func_permutation_test(part_coef_A, part_coef_B,obs_diff,Sparsity, nw_metric, mat1, mat2)
% % legend({'Mean','Upperbound(95% CI)','Lowerbound(95% CI)','A vs B'},'Location','north','Orientation','horizontal')
% saveas(gcf, 'Grp_diff_AvsB_Participation_coeff.png') % saved in above mentioned path
% 
% mat1 = 'A'; mat2 = 'AB';
% obs_diff = mean(part_coef_A,1)- mean(part_coef_AB,1);% dim: 1*11   
% TS_func_permutation_test(part_coef_A, part_coef_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
% saveas(gcf, 'Grp_diff_AvsAB_Participation_coeff.png') % saved in above mentioned path
% 
% mat1 = 'B'; mat2 = 'AB';
% obs_diff = mean(part_coef_B,1)- mean(part_coef_AB,1);% dim: 1*11   
% TS_func_permutation_test(part_coef_B, part_coef_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
% saveas(gcf, 'Grp_diff_BvsAB_Participation_coeff.png') % saved in above mentioned path

%% End