function cx_GM = TS_reg_conn(x_GM,x_X,x_age,x_gender)
cx_GM = zeros(size(x_GM));
for i = 1:size(x_GM,1)
    for j = 1:size(x_GM,2) 
        b(:,j) = regress(x_GM(:,j),x_X); % b is regression coefficient; b = regress(y,X);
        cx_GM(i,j) = x_GM(i,j) - (b(2,j).*x_age(i)+ b(3,j).*x_gender(i)+b(4,j).*x_age(i).*x_gender(i)); %cGM is corrected GM matrix obtained as cGM = GM -(b2*age + b3*gender + b4*Combined effect of both age and gender)
    end
end
clear intercept
clear b
end