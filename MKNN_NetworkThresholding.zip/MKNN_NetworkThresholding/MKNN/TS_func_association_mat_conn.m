function plot_assoc = TS_association_mat_conn(x_wtGM,mat)
ROI_names = load('LPBA_ROI_names.mat');
ROI_names = ROI_names.txt_names;
figure
imagesc(x_wtGM)
nw_title = sprintf('Binary Undirected Matrix for %s', mat);
title(nw_title)
set(gca,'XTick',1:56,'XTickLabel',ROI_names,'fontsize',6)% txt_A has region names common to all subgroups  for xlabel and ylabel
xtickangle(90)
xlabel('Regions', 'FontSize',12, 'FontWeight','bold')
set(gca,'YTick',1:56,'YTickLabel',ROI_names,'fontsize',6)
ylabel('Regions', 'FontSize',12,'FontWeight','bold')
colorbar('northoutside')

end