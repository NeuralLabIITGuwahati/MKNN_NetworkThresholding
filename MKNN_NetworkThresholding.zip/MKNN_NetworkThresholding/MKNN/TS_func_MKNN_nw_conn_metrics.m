function [deg_x, Avg_deg_x, density_x, transit_x, eff_local_x, eff_global_x, modul_x, assortativity_x, BC_x, participation_coef_x, eigen_vector_centrality_x, pl_x, lambda_x, gamma_x, sigma_x, clust_coef_x] = TS_binary_conn(mutual_X)

        % METRIC CALCULATION
        x = mutual_X;%x_3D(:,:,i); % x is input i.e., A or B or AB
        % Degree
        deg_x = degrees_und(x);
        Avg_deg_x = mean(deg_x);
        % Density
        density_x = density_und(x);
        % Transitivity
        transit_x = transitivity_bu(x);
        % Global and Local efficiency
        eff_global_x = efficiency_bin(x);
        eff_local_x = efficiency_bin(x,1);
        % Modularity
        modul_x = modularity_und(x);
        % Assortativity
        assortativity_x = assortativity_bin(x,0);
        % Rich Club
        % rich_club_x(i,:) = rich_club_bu(x);
        % Betweenness Centrality
        BC_x = (betweenness_bin(x))';
        %BC_nrml_x= BC_x/((length(x_abs)-1)*(length(x_abs)-2));
        % Participation Coefficient
        participation_coef_x= participation_coef(x, modul_x, 0);
        %Eigen Vector Centrality
        eigen_vector_centrality_x = eigenvector_centrality_und(x);

        % % Shortest Path between any two nodes
        % s =input('Enter a source node for shortest path calculation \n'); %  try 2%%%%% value between 1 to number of nodes
        % t = input('Enter a destination node for shortest path calculation \n'); % try 55%%%%% value between 1 to number of nodes
        % shortest_path_HC = retrieve_shortest_path(s,t, hops(:,:), Pmat(:,:));

        % SIGMA CALCULATION
        rand_network_x = zeros(size(x)); % creating random network (network with same number of nodes and edge as that of AA_Thresh)at each threshold
        edge = nnz(tril(x));
        for j = 1:1000
                %     k = int8(edge);
                %     b(i) = nchoosek(num_max_conn,k);
                D_x = distance_bin(x); % distance matrix    
                [pl_x(:,j),~,~,~,~] = charpath(D_x,0,0);% Characteristic path length
                clust_coef_x(:,j) = clustering_coef_bu(x);% Clustering coefficient
                rand_network_x(:,:,j) = makerandCIJ_und(56, edge);
                D_rand_x = distance_bin(rand_network_x(:,:,j));  % Distance matrix        
                [pl_rand_x(:,j),~,~,~,~] = charpath(D_rand_x,0,0);% Characteristic path length
                clust_coef_rand_x(:,j) = clustering_coef_bu(rand_network_x(:,:,j));% Clustering coefficient
        end     
        clust_coef_x = clust_coef_x(:,1);
        
        lambda_x = pl_x(1,1)./mean(pl_rand_x,2);  % 1000 lambda values for each sparsity
        gamma_x = (clust_coef_x)./(mean(clust_coef_rand_x,2));
        sigma_x = gamma_x./lambda_x;

        mean_gamma_x= mean(gamma_x,2);
        sd_gamma_x = std(gamma_x);
        mean_sigma_x = mean(sigma_x,1);
        sd_sigma_x = std(sigma_x);
end