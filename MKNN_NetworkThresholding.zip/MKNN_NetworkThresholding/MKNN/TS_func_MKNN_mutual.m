% Give correlation matrix as input
function [Assoc_X, mutual_X, num_edges_x, Density_x] = TS_MKNN_mutual(corr_x,K)
    X = corr_x;
    N = length(X);
    X = X - diag(diag(X));
    MKNN = struct('Node',[]);
    X = abs(X);
    % K is the No. of nearest neighbors
    for i = 1:N
        MKNN(i).Node = i;
        [MKNN(i).top_K_vals,MKNN(i).top_K_idx]  = sort(X(i,:),'descend');
        MKNN(i).top_7_vals = MKNN(i).top_K_vals(:,1:K);
        MKNN(i).top_7_idx = MKNN(i).top_K_idx(:,1:K);
    end

    %% K- Nearest neighbours matrix
    Assoc_X = zeros(N);
    for i = 1:N
        kt = MKNN(i).top_7_idx;
        for j = 1:length(kt)
        Assoc_X(i,kt(j)) = 1;
        end
    end

    %% Mutual K- Nearest neighbours matrix or Binary Matrix
    mutual_X = zeros(N);
    for i = 1:N
        for j = i+1:N
            if (Assoc_X(i,j) == Assoc_X(j,i)) && (Assoc_X(i,j)~=0)
                mutual_X(i,j) = 1;
                mutual_X(j,i) = 1;
            end
        end
    end
    figure
    graph(mutual_X);
    plot(ans)

    num_edges_x = triu(mutual_X);
    Density_x = nnz(num_edges_x)/(56*55/2);
end

