clc
clear all
close all
%%
load('C:\Users\TestPC\Desktop\MKNN\Mutual_corr_mat.mat')
Inp_mat = Mutual_B;
n = 56;
xx = Inp_mat;
xx( all(~xx,2), : ) = [];% Remove zero rows
xx( :, all(~xx,1) ) = [];% Remove zero columns
%% 
aa = Inp_mat;
zer = zeros(1,56);
ind = 0;
for i = 1:56
    if aa(i,:) == zer
        ind = [ind,i];
    end
end
ind = ind(2:end);
zz = setxor([1:56],ind);

%% Make a random nxN adjacency matrix
%https://in.mathworks.com/matlabcentral/answers/277484-constructing-a-bipartite-graph-from-0-1-matrix
% Expand out to symmetric (n+N)x(n+N) matrix
load('LPBA_ROI_names.mat')
n = size(xx,1);
big_a = [zeros(n,n), xx; xx', zeros(n,n)];
figure
g = graph(big_a);
h = plot(g);
h.XData(1:n) = 1;
h.XData((n+1):end) = 2;
h.YData(1:n) = linspace(0,1,n);
h.YData((n+1):end) = linspace(0,1,n+n-n);
roi_names = txt_names(zz(1:end));
% ROI_names = [roi_names roi_names];
% labelnode(h,1:n+n,ROI_names)
zzz = [zz zz];
labelnode(h,1:n+n,zzz)
title('GM to WM connections')

figure
imagesc(xx)
set(gca,'XTick',1:n,'XTickLabel',roi_names,'fontsize',10)% txt_A has region names common to all subgroups  for xlabel and ylabel
xtickangle(45)
xlabel('Regions', 'FontSize',12, 'FontWeight','bold')
set(gca,'YTick',1:n,'YTickLabel',roi_names,'fontsize',10)
ylabel('Regions', 'FontSize',12,'FontWeight','bold')

