clc
clear
close


%% GM and WM difference
load('c_subgrp_rGMV')
load('c_subgrp_rWMV')

for k = 1:size(cA_WM,1)
    for i = 1:56
        for j = 1:56
            diff_A = (cA_GM(k,i)-cA_WM(k,j)).^2;
            ind_cor_A(k,i,j) = 1/(diff_A+1);
        end
    end
end


for k = 1:size(cB_WM,1)
    for i = 1:56
        for j = 1:56
            diff_B = (cB_GM(k,i)-cB_WM(k,j)).^2;
            ind_cor_B(k,i,j) = 1/(diff_B+1);
        end
    end
end


for k = 1:size(cAB_WM,1)
    for i = 1:56
        for j = 1:56
            diff_AB = (cAB_GM(k,i)-cAB_WM(k,j)).^2;
            ind_cor_AB(k,i,j) = 1/(diff_AB+1);
        end
    end
end
%%


for i = 1:size(ind_cor_A,1)
    A = squeeze(ind_cor_A(i,:,:));
    A = A - diag(diag(A)); 
    UBNIN_A_GM_WM(i,:) = TS_Func_UBNIN(A);
    UBNINs_A_GM_WM(i,:) = vpa(TS_Func_UBNIN(A),50);
end

for i = 1:size(ind_cor_B,1)
    B = squeeze(ind_cor_B(i,:,:));
    B = B - diag(diag(B)); 
    UBNIN_B_GM_WM(i,:) = TS_Func_UBNIN(B);
    UBNINs_B_GM_WM(i,:) = vpa(TS_Func_UBNIN(B),50);
end

for i = 1:size(ind_cor_AB,1)
    AB = squeeze(ind_cor_AB(i,:,:));
    AB = AB - diag(diag(AB)); 
    UBNIN_AB_GM_WM(i,:) = TS_Func_UBNIN(AB);
    UBNINs_AB_GM_WM(i,:) = vpa(TS_Func_UBNIN(AB),50);
end

%%
unique_A_GM_WM = nnz(unique(UBNIN_A_GM_WM)) % number of unique networks in subgrp A
unique_B_GM_WM = nnz(unique(UBNIN_B_GM_WM)) % number of unique networks in subgrp A
unique_AB_GM_WM = nnz(unique(UBNIN_AB_GM_WM)) % number of unique networks in subgrp A



figure
UBNIN_all = [UBNIN_A_GM_WM;UBNIN_B_GM_WM;UBNIN_AB_GM_WM];
group= (repelem([{'A'}, {'B'},{'AB'}], [length(UBNIN_A_GM_WM), length(UBNIN_B_GM_WM), length(UBNIN_AB_GM_WM)]))';
vp_UBNIN_all_GM_WM = violinplot(UBNIN_all,group); % violin plot
xlabel('Subtypes of Parkinson''s Disease')
ylabel('UBNIN values using GM WM diff')