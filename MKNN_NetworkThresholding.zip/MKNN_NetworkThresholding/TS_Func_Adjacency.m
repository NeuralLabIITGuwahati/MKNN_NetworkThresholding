function Adj = Consistency_adjacency_mat(Association_Matrix,Density)
    I = Association_Matrix;
    I = I.*-(eye(height(I))-1); % set diagonal to zero to ignore selfloop
    % density is usually 30% i.e., retaining 30 % of edges
    num_max_conn = size(I,2)*(size(I,2)-1)/2; % 56*55/2
    num_edges = 2*(Density/100)*num_max_conn;% twice becoz A to B and B to A is counted twice
    I_1D = reshape(I,1,size(I,2)*size(I,2));
    wt = sort(I_1D,'descend');
    Thresh = wt(1:num_edges);
    Threshold = Thresh(1,end);
    I(I<=Threshold) = 0; % Sparsity of 0.9 means 90%  are off
    I(I> Threshold) = 1;% highest 10 % are considered
    Adj = I; % Thresholded binary matrix or adjacency matrix
end
