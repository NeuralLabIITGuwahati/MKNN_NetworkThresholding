clc
clear all
close all
nHC = 70;
nPD = 180;
[num, txt, raw]  = xlsread('/Volumes/Pnk_2TB/LAB_PC_11032024/Desktop/ALL/JICA/HC_PD_NIMHANS.xlsx');%'/Users/tanmayee/Desktop/JICA/NIMHANS/HC_PD_NIMHANS.xlsx');%xlsread('C:\Users\TestPC\Desktop\ALL\JICA\HC_PD_NIMHANS.xlsx'); % excel sheet with all subjects Age, Gender, Diagnosis data
txt = txt(2:end,:);
Gender = num(:,1); % Male: 1 & Female : 0
Age = num(:,2);
Diag= num(:,3); % HC: 2 & PD: 1
HCnames = txt(find(Diag == 2),1); % Names of HC 
HC_sl  =  find(Diag==2); % Sl num of HC in the excel as well as SBM matrix
PDnames = txt(find(Diag == 1),1); % Names of PD
PD_sl  =  find(Diag==1); % Sl num of PD in the excel as well as SBM matrix
 Males = find(num(:,1) ==1); % Sl no of males in the entire dataset
Females = find(num(:,1) ==0); % Sl no of females in the entire dataset
sc_both =  load('/Volumes/Pnk_2TB/LAB_PC_11032024/Desktop/ALL/JICA/JICA_output/JICA__sc_comb_1.mat'); % load('/Users/tanmayee/Desktop/JICA/NIMHANS/JICA__sc_comb_1.mat'); % load('C:\Users\TestPC\Desktop\ALL\JICA\JICA_output\JICA__sc_comb_1.mat'); % shared loading or mixing matrix
load_mat = sc_both.A; 
for i = 1:30
    % comparing the loading coeff of HC and PD for each of the 30 components
   [h(i) p(i) ci statistics] = ttest2(load_mat(HC_sl,i),load_mat(PD_sl,i)); % by default ttest 2 tests 2 sample t test at 5% significance level 
    % h = 1 implies the data in x and y comes from populations with unequal means
    %           h = 0 is reverse of h = 1 implying no group difference
end
p = p'; 
sig_comp_ttest = find(h==1);
mean_loadings = [mean(sc_both.A(1:nHC,:),1); mean(sc_both.A(nHC+1:end,:),1)];

%% FDR
[h_fdr, crit_p_fdr, adj_ci_cvrg, adj_p_fdr]=fdr_bh(p); 
% If h_fdr=1, it means that p-value is significant (i.e., Null Hypothesis is rejected), which implies grp differences exists for that component.
%            h_fdr =1 for 23 components 
% crit_p_fdr  : All uncorrected p-values (p-values which we got from ttest2 earlier) less than or equal to crit_p_fdr are 
%             significant (i.e., their null hypotheses are rejected).  If no p-values are significant, crit_p=0.
%             crit_p_fdr = 0.0088. 
%             Components with p values < or = crit_p_fdr are true positives.
 % adj_p   - All adjusted p-values less than or equal to q(here q=0.05, taken by default if not mentioned) 
%             are significant (i.e., their null hypotheses are rejected). Note, adjusted p-values can be greater than 1.
%              Components with adj_p_fdr < 0.05 are again true positives.
% https://in.mathworks.com/matlabcentral/fileexchange/27418-fdr_bh
sig_comp = find(h_fdr == 1);  % significant components
[sorted_sig_P, idx_P] = sort(adj_p_fdr(sig_comp)); 
%% Cohen's d test, Hedge's g test and top two components
sig_load_mat = load_mat(:,sig_comp_ttest);
for i = 1:30
    mean_HC(i) = mean(load_mat(HC_sl,i),1);  std_HC (i) = std(load_mat(HC_sl,i)); 
    mean_PD(i) = mean(load_mat(PD_sl,i),1);  std_PD (i) = std(load_mat(PD_sl,i));
    numerator(i) = mean_HC(i) - mean_PD(i);
    denominator(i) = sqrt((((numel(HC_sl)-1)*(std_HC(i).^2)) + ((numel(PD_sl)-1)*(std_PD(i).^2)))/(numel(HC_sl)+numel(PD_sl)-2));
    d_Cohen(i) = abs(numerator(i)/denominator(i)); % Cohen's d test is applicable for sample size < 20
end

% Hedges's g test
 Hedges_g = d_Cohen *(1-(3/(4*(numel(HC_sl)+numel(PD_sl))-9))); % Hedges's g test is applicable for sample size >20. It's correction of Cohens's d test.
[Hedge_Effect_size, idx_effect] =  sort(Hedges_g, 'descend');
ss = [23,28]; % Manually looked for loading coeff of Inferior frontal gyrus and Middle & Superior Frontal Gyrus

two_sig_comp = load_mat(:,ss); % for one scanner
% two_sig_comp = load_mat(:,idx_effect(1:2)); % loading coeff of top two sig components

%% Bar plot for Hedge's g test
figure
bh = barh(Hedges_g)
xlim([0 4.5]);
CData = [1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297;1 0.75 0.79297]
CData(1,:) = [1 0.8 0.8]
bh.FaceColor = 'flat'
bh.CData(:,:) =CData;
% CData(5,:) = [0.5 0 0.5]
% CData(14,:) = [0.5 0 0.5];
% CData(8,:) = [0.5 0 0.5];
CData(28,:) = [0.5 0 0.5];
CData(23,:) = [0.5 0 0.5];
bh.FaceColor = 'flat'
bh.CData(:,:) =CData;
set(gca,'ytick',1:30);
Y = Hedges_g;
xtips1 = bh(1).YEndPoints + 0.2;
ytips1 = bh(1).XEndPoints;
labels1 = string(bh(1).YData);
text(xtips1,ytips1,labels1,'VerticalAlignment','middle')

xtips1 = bh(1).YEndPoints + 0.2;
ytips1 = bh(1).XEndPoints;
labels1 = string(bh(1).YData);
text(xtips1,ytips1,labels1,'VerticalAlignment','middle')
%saveas(gcf, 'C:\Users\TestPC\Desktop\ALL\JICA\EffectSize_JICA_NIMHANS.png') % saved in above mentioned path

%% Thresholding by N-BiC method
 
two_sig_comp_PD = two_sig_comp(PD_sl,:); % 1st column is for component 23 (i.e. component with highest effect size) and 2nd column is for component 28 (i.e. 2nd highest effect size)
mean_of_comp = mean(two_sig_comp_PD,1);
%subgrp 1: from comp 20 only
 if mean_of_comp(1,1) > 0
        idx_1 = find(two_sig_comp_PD(:,1) >= mean_of_comp(1,1) );
else
        idx_1  = find(two_sig_comp_PD(:,1) < mean_of_comp(1,1) );
end
% subgrp2: from comp 14 only
if mean_of_comp(1,2) > 0
        idx_2 = find(two_sig_comp_PD(:,2) >= mean_of_comp(1,2) );
else
        idx_2  = find(two_sig_comp_PD(:,2) < mean_of_comp(1,2) );
end

%% Subgroup specific subjects from PD subjects only

Grp_AB_idx = intersect(idx_1, idx_2);        % index common to both A and B
 Grp_AB_names = PDnames(Grp_AB_idx);     % names of subjects common to both A & B

 Grp_A_idx = setdiff(idx_1,Grp_AB_idx);            % exclusively subgroup  A subjects
Grp_A_names = PDnames(Grp_A_idx);

 Grp_B_idx = setdiff(idx_2,Grp_AB_idx);         % exclusively subgroup B subjects
 Grp_B_names = PDnames(Grp_B_idx); 
% setdiff(X,Y) will give elements of X which are not Y


%% Females and males count in each subgroup

 F_A = find(Gender(70+Grp_A_idx)==0);
M_A = find(Gender(70+Grp_A_idx)==1);
 F_B = find(Gender(70+Grp_B_idx)==0);
M_B = find(Gender(70+Grp_B_idx)==1);
 F_AB = find(Gender(70+Grp_AB_idx)==0);
M_AB = find(Gender(70+Grp_AB_idx)==1);
%% ANOVA on subgroup-specific loadings
PD_loadings = load_mat(PD_sl,:);
j = ss;%idx_effect(1:2) % Top five significant components
 group= repelem([{'A'}, {'B'}, {'AB'}], [size(Grp_A_idx,1), size(Grp_B_idx,1), size(Grp_AB_idx,1)]);
 for i = 1:2
    loading_A(:,i) = PD_loadings(Grp_A_idx,j(i));
    loading_B(:,i) = PD_loadings(Grp_B_idx,j(i));
    loading_AB(:,i) = PD_loadings(Grp_AB_idx,j(i));
    A = loading_A(:,i);
    B = loading_B(:,i);
    AB = loading_AB(:,i);
    y_loading =[A' B' AB']; % concatenated loading coefficients of all subgroups
    [p_anova_load,table_load, stats_load] = anova1(y_loading,group);
    p_anova_loadng(i) = p_anova_load;
 end
 %% ANOVA of subgroup- specific age
group= repelem([{'A'}, {'B'}, {'AB'}], [size(Grp_A_idx,1), size(Grp_B_idx,1), size(Grp_AB_idx,1)]);

Age_A = Age(nHC+Grp_A_idx);
Range_Age_A = [min(Age_A) max(Age_A)];

Age_B = Age(nHC+Grp_B_idx);
Range_Age_B = [min(Age_B) max(Age_B)];

Age_AB = Age(nHC+Grp_AB_idx);
 Range_Age_AB = [min(Age_AB) max(Age_AB)];

y_Age =[Age_A' Age_B' Age_AB']; % concatenated loading coefficients of all subgroups
[p_anova_load,table_load, stats_load] = anova1(y_Age,group);
p_anova_loadng(i) = p_anova_load;
    
%% missing values in  Clinical data of PD subjects only
 UPDRS_off_miss = find(isnan(num(nHC+1:end,4))); % index of missing values in UPDRS_off
 count_missing_UPDRS_off = nnz(UPDRS_off_miss);
 UPDRS_on_miss = find(isnan(num(nHC+1:end,5))); % index of missing values in UPDRS_on
 count_missing_UPDRS_on = nnz(UPDRS_on_miss);
 HY_miss =find( isnan(num(nHC+1:end,6))); % index of missing values in H&Y
 count_missing_HY = nnz(HY_miss);
 Age_onset_miss =  find(isnan(num(nHC+1:end,7))); % index of missing values in Age at onset
 count_missing_Age_onset = nnz(Age_onset_miss);
 
 %% Winsorized Mean 90% 
 % Here 90% winsorization =>10 % data will be modified => 5% data will be
 % modified from both tail end
 % Winsorized mean of UPDRS off
UPDRS_off_avail_idx = find(~isnan(num(71:250,4))); % 4th column has UPDRS off
UPDRS_off_avail = sort(num(70+UPDRS_off_avail_idx,4));
a = mean(UPDRS_off_avail)
UoffPercent_5 = round((size(UPDRS_off_avail,1)*0.1)/2); % divided by 2 coz from both ends 
UPDRS_off_avail(1:UoffPercent_5) = UPDRS_off_avail(1 + UoffPercent_5);
UPDRS_off_avail(end:-1:end-UoffPercent_5+1) = UPDRS_off_avail(end-UoffPercent_5);
Winsor_UP_off = mean(UPDRS_off_avail); %Winsor is winsorized mean
  % Winsorized mean of UPDRS on
UPDRS_on_avail_idx = find(~isnan(num(71:250,5)));% 5th column has UPDRS on
UPDRS_on_avail = sort(num(70+UPDRS_on_avail_idx,5));
b = mean(UPDRS_on_avail)
UonPercent_5 = round((size(UPDRS_on_avail,1)*0.1)/2); % divided by 2 coz from both ends
UPDRS_on_avail(1:UonPercent_5) = UPDRS_on_avail(1 + UonPercent_5);
UPDRS_on_avail(end:-1:end-UonPercent_5+1) = UPDRS_on_avail(end-UonPercent_5);
Winsor_UP_on = mean(UPDRS_on_avail);
  % since H&Y is a categorical value, it's median would be better than winsorised mean .
HY_avail_idx = find(~isnan(num(71:250,6))); % 6th column has H&Y
HY_median = median(num(70+HY_avail_idx,6));
   % Winsorized mean of Age at onset
 onset_avail_idx = find(~isnan(num(71:250,7))); % 7th column has age at onset
onset_avail = sort(num(70+onset_avail_idx,7));
d = mean(onset_avail)
onsetPercent_5 = round((size(onset_avail,1)*0.1)/2); % divided by 2 coz from both ends
onset_avail(1:onsetPercent_5) = onset_avail(1 + onsetPercent_5);
onset_avail(end:-1:end-onsetPercent_5+1) = onset_avail(end-onsetPercent_5);
Winsor_onset = mean(onset_avail);

 %% Imputing winsorized mean in missing values for UPDRS off, on, age at onset and median for H&Y
 num(70 + UPDRS_off_miss,4) = Winsor_UP_off;
 num(70 + UPDRS_on_miss,5) = Winsor_UP_on;
 num(70 + HY_miss,6) = HY_median;
 num(70 + Age_onset_miss,7) = Winsor_onset;
 
 UP_off_A = num(70+Grp_A_idx,4);
 UP_off_B = num(70+Grp_B_idx,4);
 UP_off_AB = num(70+Grp_AB_idx,4);

 UP_on_A = num(70+Grp_A_idx,5);
 UP_on_B = num(70+Grp_B_idx,5);
 UP_on_AB = num(70+Grp_AB_idx,5);
 
HY_A = num(70+Grp_A_idx,6);
 HY_B = num(70+Grp_B_idx,6);
 HY_AB = num(70+Grp_AB_idx,6);
 
onset_A = num(70+Grp_A_idx,7);
onset_B = num(70+Grp_B_idx,7);
onset_AB = num(70+Grp_AB_idx,7);

mean(UP_off_A)
std(UP_off_A)
mean(UP_off_B)
std(UP_off_B)
mean(UP_off_AB)
std(UP_off_AB)

mean(HY_A)
std(HY_A)
mean(HY_B)
std(HY_B)
mean(HY_AB)
std(HY_AB)


mean(onset_A)
std(onset_A)
mean(onset_B)
std(onset_B)
mean(onset_AB)
std(onset_AB)
 %% ANOVA for subgroup specific clinical data 
y_UP_off = [UP_off_A' UP_off_B' UP_off_AB']; % concatenated the UPDRS off values of all subgroups
group= repelem([{'A'}, {'B'}, {'AB'}], [size(UP_off_A,1), size(UP_off_B,1), size(UP_off_AB,1)]);
 [p_anova_off,table_off, stats_off] = anova1(y_UP_off,group);
 if p_anova_off < 0.05
     display('There is a significant difference between the groups for UPDRS off')
 else
     display ('There is NO significant difference between the groups for UPDRS off')
 end
 
 y_UP_on = [UP_on_A' UP_on_B' UP_on_AB']; 
 [p_anova_on,table_on, stats_on] = anova1(y_UP_on,group);
 if p_anova_on < 0.05
     display('There is a significant difference between the groups for UPDRS on')
 else
     display ('There is NO significant difference between the groups for UPDRS on')
 end
 
 y_HY = [HY_A' HY_B' HY_AB']; 
 [p_anova_HY,table_HY, stats_HY] = anova1(y_HY,group);
 if p_anova_HY< 0.05
     display('There is a significant difference between the groups for HY')
 else
     display ('There is NO significant difference between the groups for HY')
 end
 
 y_onset = [onset_A' onset_B' onset_AB']; 
 [p_anova_onset,table_onset, stats_onset] = anova1(y_onset,group);
 if p_anova_onset < 0.05
     display('There is a significant difference between the groups for age at onset')
 else
     display ('There is NO significant difference between the groups for age at onset')
 end
 
 %% Correlation of clinical variables with GM loadings

% loadings and UPDRS_off
 [rho_corr_loadA_UPoff(i),pval_corr_loadA_UPoff(i)] = corr(loading_A(:,i),UP_off_A);
 [rho_corr_loadB_UPoff(i),pval_corr_loadB_UPoff(i)] = corr(loading_B(:,i),UP_off_B);
 [rho_corr_loadAB_UPoff(i),pval_corr_loadAB_UPoff(i)] = corr(loading_AB(:,i),UP_off_AB);

 % loadings and UPDRS_on
 [rho_corr_loadA_UPon(i),pval_corr_loadA_UPon(i)] = corr(loading_A(:,i),UP_on_A);
 [rho_corr_loadB_UPon(i),pval_corr_loadB_UPon(i)] = corr(loading_B(:,i),UP_on_B);
 [rho_corr_loadAB_UPon(i),pval_corr_loadAB_UPon(i)] = corr(loading_AB(:,i),UP_on_AB);

 % loadings and H&Y
 [rho_corr_loadA_HY(i),pval_corr_loadA_HY(i)] = corr(loading_A(:,i),HY_A);
 [rho_corr_loadB_HY(i),pval_corr_loadB_HY(i)] = corr(loading_B(:,i),HY_B);
 [rho_corr_loadAB_HY(i),pval_corr_loadAB_HY(i)] = corr(loading_AB(:,i),HY_AB);

 % loadings and age at onset
 [rho_corr_loadA_onset(i),pval_corr_loadA_onset(i)] = corr(loading_A(:,i),onset_A);
 [rho_corr_loadB_onset(i),pval_corr_loadB_onset(i)] = corr(loading_B(:,i),onset_B);
 [rho_corr_loadAB_onset(i),pval_corr_loadAB_onset(i)] = corr(loading_AB(:,i),onset_AB);
 
  % loadings and onset
 [rho_corr_loadA_age(i),pval_corr_loadA_age(i)] = corr(loading_A(:,i),Age_A);
 [rho_corr_loadB_age(i),pval_corr_loadB_age(i)] = corr(loading_B(:,i),Age_B);
 [rho_corr_loadAB_age(i),pval_corr_loadAB_age(i)] = corr(loading_AB(:,i),Age_AB);
 
% Because the p-value is less than the significance level of 0.05,
... it indicates rejection of the hypothesis that no correlation exists between the two columns
    