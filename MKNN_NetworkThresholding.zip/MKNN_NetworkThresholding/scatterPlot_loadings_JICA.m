% NIMHANS data
nHC = 70;
nPD = 180;

cd /Users/tanmayee/Desktop/JICA/NIMHANS/Final%C:\Users\TestPC\Desktop\ALL\JICA
sc_both =load('JICA__sc_comb_1.mat'); % shared loading or mixing matrix
grp_load_coeff = sc_both.A; % Loading matrix 250*30
HC = grp_load_coeff(1:nHC,:);
PD = grp_load_coeff(nHC+1:end,:);
sig_comp = [23,28];
HC_sig_comp = HC(:,sig_comp);
PD_sig_comp = PD(:,sig_comp);
figure
scatter(HC_sig_comp(:,1),HC_sig_comp(:,2),'g','filled','MarkerEdgeColor',[0 .5 .5]) % scatter plot: x-axis: HC in comp 1, y-axis: HC in comp 2  
hold on
scatter(PD_sig_comp(:,1),PD_sig_comp(:,2),'r','filled')% scatter plot: x-axis: PD in comp 1, y-axis: PD in comp 2  
legend('HC','PD')
xlabel('Loadings of IFG-Th-Cul-RG')
ylabel('Loadings of SG-SMG-STG-MTG')

%% Subgrp loadings
load('Subgrp_subj.mat')
A1 = PD_sig_comp(Grp_A_idx,1);
A2 = PD_sig_comp(Grp_A_idx,2);
B1 = PD_sig_comp(Grp_B_idx,1);
B2 = PD_sig_comp(Grp_B_idx,2);
AB1 = PD_sig_comp(Grp_AB_idx,1);
AB2 = PD_sig_comp(Grp_AB_idx,2);
figure
scatter(A1,A2,'y','filled','MarkerEdgeColor',[0.8500 0.3250 0.0980])
hold on
scatter(B1,B2,'m','filled')%,'MarkerFaceColor',[1 0.6 0.8],'MarkerEdgeColor',[0.4 0 0.4])
hold on
scatter(AB1,AB2,'c','filled','MarkerEdgeColor','b')
legend('Subgroup A','Subgroup B','Subgroup AB')
xlabel('Loadings of IFG-Th-Cul-RG')
ylabel('Loadings of SG-SMG-STG-MTG')
%%
figure
scatter(HC_sig_comp(:,1),HC_sig_comp(:,2),'g','filled','MarkerEdgeColor',[0 .5 .5]) % scatter plot: x-axis: HC in comp 1, y-axis: HC in comp 2  
% hold on
% scatter(PD_sig_comp(:,1),PD_sig_comp(:,2),'r','filled')% scatter plot: x-axis: PD in comp 1, y-axis: PD in comp 2  
hold on
scatter(A1,A2,'y','filled','MarkerEdgeColor',[0.8500 0.3250 0.0980])
hold on
scatter(B1,B2,'m','filled')%,'MarkerFaceColor',[1 0.6 0.8],'MarkerEdgeColor',[0.4 0 0.4])
hold on
scatter(AB1,AB2,'c','filled','MarkerEdgeColor','b')
legend('HC','Subgroup A','Subgroup B','Subgroup AB')
xlabel('Loadings of IFG-Th-Cul-RG')
ylabel('Loadings of SG-SMG-STG-MTG')

