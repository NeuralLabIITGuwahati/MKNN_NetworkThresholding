function K = UBNIN(AM)
A = AM;% adjacency matrix
triu_a=triu(A,1);
D=[];
s = length(A);
% Get the decimal equivalent of binary number
for i = 1:s % column
    an=0;
    power=0;
    for j = 1:s % row
        an=an+triu_a(j,i)*2^power;
        power=power+1;
    end
    D(end+1)=an;
end
power=1;
%temp=D_half(2);
temp = D(2);
% Get the final value
for i=2:length(triu_a)-1
    K=temp*(1/2^power);
    K=K+D(i+1);
    power=power+1;
    temp=K;
    each_val(i-1) = K;
end

